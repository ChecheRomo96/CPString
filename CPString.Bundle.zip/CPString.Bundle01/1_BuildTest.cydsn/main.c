/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
extern "C"{
    #include "project.h"
}

#include<CPString.h>

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
	UART_1_Start();
	UART_1_PutString(CPString::string("This project uses CPString version:").c_str());
	UART_1_PutString(CPSTRING_VERSION);
    UART_1_PutChar('\n');
    UART_1_PutChar('\r');
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
